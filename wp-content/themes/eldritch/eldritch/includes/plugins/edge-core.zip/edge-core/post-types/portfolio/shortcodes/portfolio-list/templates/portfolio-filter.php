<div
	class="edgt-portfolio-filter-holder <?php echo esc_attr($masonry_filter) ?>" <?php //eldritch_edge_inline_style($filter_styles); ?>>
	<div class="edgt-portfolio-filter-holder-inner">
		<?php echo eldritch_edge_get_module_part($filter_categories); ?>
	</div>
</div>