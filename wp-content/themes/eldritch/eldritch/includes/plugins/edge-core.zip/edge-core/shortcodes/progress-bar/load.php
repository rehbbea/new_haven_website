<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/progress-bar/progress-bar.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/progress-bar/custom-styles/progress-bar.php';

