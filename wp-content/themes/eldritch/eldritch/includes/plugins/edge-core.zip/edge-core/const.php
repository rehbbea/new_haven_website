<?php

define('EDGE_CORE_VERSION', '1.1.1');
define('EDGE_CORE_ABS_PATH', dirname(__FILE__));
define('EDGE_CORE_REL_PATH', dirname(plugin_basename(__FILE__)));
define('EDGE_CORE_CPT_PATH', EDGE_CORE_ABS_PATH.'/post-types');
define('EDGE_CORE_SHORTCODES_PATH', EDGE_CORE_ABS_PATH . '/shortcodes' );