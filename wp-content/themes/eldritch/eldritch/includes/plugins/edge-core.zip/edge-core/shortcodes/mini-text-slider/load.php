<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/mini-text-slider/mini-text-slider.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/mini-text-slider/mini-text-slider-item.php';
