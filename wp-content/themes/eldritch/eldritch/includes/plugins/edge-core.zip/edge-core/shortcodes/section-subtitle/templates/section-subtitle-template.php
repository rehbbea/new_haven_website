<div <?php eldritch_edge_class_attribute($classes); ?> <?php eldritch_edge_inline_style($holder_styles); ?>>
	<p <?php eldritch_edge_inline_style($styles); ?> class="edgt-section-subtitle"><?php echo wp_kses_post($text); ?></p>
</div>