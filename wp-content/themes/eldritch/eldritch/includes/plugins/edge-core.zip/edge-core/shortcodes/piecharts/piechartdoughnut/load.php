<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/piecharts/piechartdoughnut/pie-chart-doughnut.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/piecharts/piechartdoughnut/custom-styles/pie-chart-doughnut.php';