<div <?php eldritch_edge_class_attribute($holder_classes); ?>>
	<div
		class="edgt-team-slider <?php echo esc_attr($slider_type); ?>" <?php echo eldritch_edge_get_inline_attrs($data_attrs); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>