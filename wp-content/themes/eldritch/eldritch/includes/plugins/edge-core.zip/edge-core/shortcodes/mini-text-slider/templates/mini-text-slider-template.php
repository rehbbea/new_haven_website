<div <?php eldritch_edge_class_attribute($classes); ?>>
	<div class="edgt-mts-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>