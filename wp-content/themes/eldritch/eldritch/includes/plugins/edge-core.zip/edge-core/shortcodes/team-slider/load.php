<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/team-slider/team-slider.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/team-slider/team-slider-item.php';