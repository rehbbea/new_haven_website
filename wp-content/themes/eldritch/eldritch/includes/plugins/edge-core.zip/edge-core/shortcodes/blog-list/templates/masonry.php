<?php

eldritch_edge_get_post_format_html('masonry');