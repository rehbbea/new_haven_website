<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/video-banner/video-banner.php';