<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/image-with-text-over/image-with-text-over.php';