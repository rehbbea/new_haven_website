<?php
include_once EDGE_CORE_ABS_PATH.'/shortcodes/twitter-slider/twitter-slider.php';