<?php
/**
 * Custom styles for Call To Action shortcode
 * Hooks to eldritch_edge_style_dynamic hook
 */

//if (!function_exists('eldritch_edge_call_to_action_style')) {
//
//	function eldritch_edge_call_to_action_style()
//	{
//
//		if (eldritch_edge_options()->getOptionValue('option_value') !== '') {
//			echo eldritch_edge_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => eldritch_edge_filter_px(eldritch_edge_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('eldritch_edge_style_dynamic', 'eldritch_edge_call_to_action_style');
//
//}

?>