<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/pricing-table-with-icon/pricing-tables.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/pricing-table-with-icon/pricing-table.php';