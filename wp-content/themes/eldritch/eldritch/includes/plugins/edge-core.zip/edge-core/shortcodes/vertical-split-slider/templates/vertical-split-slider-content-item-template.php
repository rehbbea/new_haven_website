<div class="edgt-vss-ms-section" <?php eldritch_edge_inline_style($content_style);?> <?php echo eldritch_edge_get_inline_attrs($content_data); ?>>
	<?php echo do_shortcode($content); ?>
</div>